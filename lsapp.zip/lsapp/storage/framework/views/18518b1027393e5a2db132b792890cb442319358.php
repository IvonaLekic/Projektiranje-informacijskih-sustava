<?php $__env->startSection('content'); ?>
</br>
  <h1> Korisnici </h1>
  <?php if(count($users) > 0): ?>
  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class ="card card-body bg-light"
           <h3><a href="/users/<?php echo e($user->email); ?>"><?php echo e($user->title); ?></a></h3>
           <small><?php echo e($user->email); ?> 
              <?php echo e(Form::open(array('action' => ['UserController@destroy', $user->id]))); ?>

              <?php if(auth()->guard()->check()): ?>
              <?php if(Auth::user()->type == 'admin'): ?>
<?php echo e(Form::hidden('_method', 'DELETE')); ?>

<?php echo e(Form::submit('Obriši', ['class' =>'btn btn-danger'])); ?>

             <?php endif; ?>
             <?php endif; ?>
<?php echo Form::close(); ?>

          
          </small>
      </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </br>
  <?php echo e($users->links()); ?>

<?php else: ?>
  <p>Nema korisnika</p>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>