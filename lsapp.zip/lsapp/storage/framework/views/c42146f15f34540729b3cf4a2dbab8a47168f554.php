<?php $__env->startSection('content'); ?>
</br>
<?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->type == 'admin' ||Auth::user()->type == 'normal_user'): ?>
            <h1> Recenzije</h1> <h5> <a href="/posts/create"> Napiši novu recenziju </a> </h5>
        <?php endif; ?>
<?php endif; ?>
    <?php if(count($posts) > 0): ?>
       <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class ="card card-body bg-light"
                <h3><a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></h3>
                <small>Datum pisanja <?php echo e($post->created_at); ?></small>
           </div>

       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </br>
       <?php echo e($posts->links()); ?>

    <?php else: ?>
       <p>Trenutno nema recenzija.</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>