<?php $__env->startSection('content'); ?>
</br>
<h1>Edit post</h1>
<?php echo e(Form::open(array('action' => ['PostController@update', $post->id]))); ?>

<div class="form-group">
        <?php echo Form::label('title', 'Title:', ['class' => 'col-lg-2 control-label']); ?>

        <div class="col-lg-10">
            <?php echo Form::text('title', $post->title, ['class' => 'form-control', 'placeholder' => 'Title']); ?>

        </div>
    </div>
<div class="form-group">
        <?php echo Form::label('body', 'Body', ['class' => 'col-lg-2 control-label']); ?>

        <div class="col-lg-10">
            <?php echo Form::textarea('body', $post->body, ['id' => 'article-ckeditor', 'class' => 'form-control', 'rows' => 5, 'placeholder' => 'Body text']); ?>

        </div>
    </div>
    <?php echo e(Form::hidden('_method', 'PUT')); ?>

    &ensp; &nbsp; <?php echo e(Form::submit('Submit', ['class' =>'btn btn-dark'])); ?>

    <?php echo Form::close(); ?>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>