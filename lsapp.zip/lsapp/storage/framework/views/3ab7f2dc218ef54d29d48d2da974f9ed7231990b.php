<?php $__env->startSection('content'); ?>
</br>
<h1><?php echo e($user->title); ?></h1>
<div>
    <?php echo $user->body; ?>

</div>
<hr>
<small><?php echo e($user->email); ?></small>
</br>
</br>
<a href="/users" class="btn btn-dark">Korisnici</a>
<hr>
<?php echo e(Form::open(array('action' => ['UserController@destroy', $user->id]))); ?>

<?php echo e(Form::hidden('_method', 'DELETE')); ?>

<?php echo e(Form::submit('Obriši', ['class' =>'btn btn-danger'])); ?>

                
<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>