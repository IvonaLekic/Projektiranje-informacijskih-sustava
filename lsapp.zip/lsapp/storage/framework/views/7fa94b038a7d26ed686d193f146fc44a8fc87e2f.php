<?php $__env->startSection('content'); ?>
</br>
<h1>Create a post</h1>
<?php echo e(Form::open(array('action' => 'UserController@store'))); ?>

<div class="form-group">
        <?php echo Form::label('ime', 'Ime:', ['class' => 'col-lg-2 control-label']); ?>

        <div class="col-lg-10">
            <?php echo Form::text('title', $value = null, ['class' => 'form-control', 'placeholder' => 'Title']); ?>

        </div>
    </div>
    <div class="form-group">
        <?php echo Form::label('prezime', 'Prezime:', ['class' => 'col-lg-2 control-label']); ?>

        <div class="col-lg-10">
            <?php echo Form::text('title', $value = null, ['class' => 'form-control', 'placeholder' => 'Title']); ?>

        </div>
    </div>
    <div class="form-group">
        <?php echo Form::label('email', 'Email:', ['class' => 'col-lg-2 control-label']); ?>

        <div class="col-lg-10">
            <?php echo Form::text('title', $value = null, ['class' => 'form-control', 'placeholder' => 'Title']); ?>

        </div>
    </div>
    
    &ensp; &nbsp; <?php echo e(Form::submit('Submit', ['class' =>'btn btn-dark'])); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>